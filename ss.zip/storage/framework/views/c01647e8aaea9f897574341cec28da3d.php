<?php $__env->startSection('content'); ?>
    <header id="top-navbar" class="site_lr-spacer back-with-text">
        <a href="javascript:history.go(-1)">
            <img class="nav-header back-btn" src="assets/images/svg/back-btn-top.svg" alt="back-btn-top">
        </a>
        <div class="header-title">
            <h1>Logout</h1>
        </div>
    </header>
    <!-- ====================================== Logout Screen Start ===================================== -->
    <section class="section-main mb-3 mt-3">
        <div class="vector-images-box">
            <img src="assets/images/vector-images/img9.png" alt="img9" style="height: 200px;">
        </div>
        <h2 class="contact-us-text-main">Logout</h2>
        <p class="ace">Are you sure you want to log out?</p>        
        <div class="button-main splash-btns-bottoms" style="display: flex; gap: 10px; margin-top: 20px;">
            <a href="<?php echo e(route('home')); ?>" class="skip-btn">No</a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                style="width: 100%; padding: 12px; text-align: center; font-weight: 700;" class="main-bg-color-btn logout">
                <?php echo csrf_field(); ?>
                <button type="submit" class="main-bg-color-btn logout">Yes, Logout</button>
            </form>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.core.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /opt/lampp/htdocs/eventposterdownloader/resources/views/layouts/core/pages/logout.blade.php ENDPATH**/ ?>