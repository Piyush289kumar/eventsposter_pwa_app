  <section class="setting-section">
      <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
          <div class="offcanvas-header">
              <h2 class="offcanvas-title" id="offcanvasExampleLabel">Settings</h2>
              <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
              
              <a href="<?php echo e(route('about')); ?>" class="home-setting-icons-main">
                  <div class="setting-opestion-main">
                      <div class="setting-icons-main">
                          <img src="assets/images/svg/aboutVoice.svg" alt="aboutVoice">
                      </div>
                      <h2 class="new-notification">About WEvoice</h2>
                  </div>
                  <p class="version">v1.0.1</p>
                  <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg"
                      alt="right-half-arrow-black">
              </a>
              <a href="<?php echo e(route('feedback')); ?>" class="home-setting-icons-main">
                  <div class="setting-opestion-main">
                      <div class="setting-icons-main">
                          <img src="assets/images/svg/feedback-icon.svg" alt="feedback-icon">
                      </div>
                      <h2 class="new-notification">Send Feedback</h2>
                  </div>
                  <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg"
                      alt="right-half-arrow-black">
              </a>
              <a href="<?php echo e(route('contact')); ?>" class="home-setting-icons-main">
                  <div class="setting-opestion-main">
                      <div class="setting-icons-main">
                          <img src="assets/images/svg/contactUs-icon.svg" alt="contactUs-icon">
                      </div>
                      <h2 class="new-notification">Contact Us</h2>
                  </div>
                  <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg"
                      alt="right-half-arrow-black">
              </a>
              <a href="<?php echo e(route('invite')); ?>" class="home-setting-icons-main">
                  <div class="setting-opestion-main">
                      <div class="setting-icons-main">
                          <img src="assets/images/svg/inviteFriend-icon.svg" alt="inviteFriend-icon">
                      </div>
                      <h2 class="new-notification">Invite Friends</h2>
                  </div>
                  <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg"
                      alt="right-half-arrow-black">
              </a>
              
              <a href="<?php echo e(route('logoutcore')); ?>" class="home-setting-icons-main mb-0">
                  <div class="setting-opestion-main">
                      <div class="setting-icons-main setting-icons-main2">
                          <img src="assets/images/svg/logOut-icon.svg" alt="logOut-icon">
                      </div>
                      <h2 class="new-notification">Logout</h2>
                  </div>
                  <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg"
                      alt="right-half-arrow-black">
              </a>
          </div>
      </div>
  </section>
<?php /**PATH /opt/lampp/htdocs/eventposterdownloader/resources/views/layouts/core/sidenav.blade.php ENDPATH**/ ?>