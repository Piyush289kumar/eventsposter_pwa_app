<?php $__env->startSection('content'); ?>
    <section class="section-main section-main-ver">
        <a href="<?php echo e(route('profile')); ?>">
            <div class="account-profile-main ">
                <div class="account-profile-main-sub">
                    <img class="account-img"
                        src="<?php echo e($user->profile_photo_path ? asset('storage/' . $user->profile_photo_path) : asset('assets/images/account-profile/account-img.jpg')); ?>" alt="account-img" style="height: 80px;">
                    <div>
                        <h2 class="Jessica"><?php echo e($user->name ?? 'Guest User'); ?></h2>
                        <p class="Jessica-number"><?php echo e($user->email ?? 'Not Logged In'); ?></p>
                    </div>
                </div>
                <div class="edit-icon-svg">
                    <img src="assets/images/svg/right-half-arrow-black.svg" alt="right-half-arrow-black">
                </div>
            </div>
        </a>
        <div class="upgradePro-main-pro">
            <div class="upgradePro-main">
                <div class="crown-main">
                    <img src="assets/images/home-screen/crown.png" alt="crown">
                </div>
                <p class="toPro">Upgrade to Pro!</p>
                <p class="njoy">Enjoy all benefits without any restrictions.</p>
            </div>
            <div class="heek">
                <a href="upgradePlan.html" class="upgradeNowButton">Upgrade Now</a>
            </div>
        </div>
        <a href="billingSubscriptions.html" class="home-setting-icons-main">
            <div class="setting-opestion-main">
                <div class="setting-icons-main">
                    <img src="assets/images/svg/security.svg" alt="security">
                </div>
                <h2 class="new-notification">Frames</h2>
            </div>
            <img class="setting-arrow" src="assets/images/svg/right-half-arrow-black.svg" alt="right-half-arrow-black">
        </a>
        
        
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.core.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /opt/lampp/htdocs/eventposterdownloader/resources/views/layouts/core/pages/account.blade.php ENDPATH**/ ?>