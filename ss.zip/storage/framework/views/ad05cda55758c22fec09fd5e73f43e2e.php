 <header id="top-navbar" class="site_lr-spacer homeHeader-main">
     <a href="<?php echo e(route('home')); ?>">
         <img class="nav-header" src="assets/images/svg/logo.svg" alt="homeLogo" style="height: 30px;">
         <span class="text-dark mx-1" style="font-weight: 750;"><?php echo e(config('app.name', 'Laravel')); ?></span>
     </a>
     <div class="homeHeader">
         
         <a href="#offcanvasExample" aria-controls="offcanvasExample" data-bs-toggle="offcanvas">
             <img src="assets/images/svg/buttonSettings.svg" alt="buttonSettings">
         </a>
     </div>
 </header>
<?php /**PATH /opt/lampp/htdocs/eventposterdownloader/resources/views/layouts/core/header.blade.php ENDPATH**/ ?>