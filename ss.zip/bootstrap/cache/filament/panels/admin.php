<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.background-resource.pages.create-background' => 'App\\Filament\\Resources\\BackgroundResource\\Pages\\CreateBackground',
    'app.filament.resources.background-resource.pages.edit-background' => 'App\\Filament\\Resources\\BackgroundResource\\Pages\\EditBackground',
    'app.filament.resources.background-resource.pages.list-backgrounds' => 'App\\Filament\\Resources\\BackgroundResource\\Pages\\ListBackgrounds',
    'app.filament.resources.frame-resource.pages.create-frame' => 'App\\Filament\\Resources\\FrameResource\\Pages\\CreateFrame',
    'app.filament.resources.frame-resource.pages.edit-frame' => 'App\\Filament\\Resources\\FrameResource\\Pages\\EditFrame',
    'app.filament.resources.frame-resource.pages.list-frames' => 'App\\Filament\\Resources\\FrameResource\\Pages\\ListFrames',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Resources/BackgroundResource.php' => 'App\\Filament\\Resources\\BackgroundResource',
    '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Resources/FrameResource.php' => 'App\\Filament\\Resources\\FrameResource',
    '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Resources/UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => '/opt/lampp/htdocs/eventposterdownloader/app/Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);